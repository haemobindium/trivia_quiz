class Answer < ApplicationRecord
  belongs_to :quiz
end
